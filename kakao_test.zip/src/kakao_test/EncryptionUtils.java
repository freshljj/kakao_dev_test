package kakao_test;

import java.security.MessageDigest;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;



public class EncryptionUtils {

	static String  encryptionAESKey   = "kakaoDevTest2020";
  	
	/*
	 * SHA-256 알고리즘을 적용한다
	 */
	
    public static String encryptSHA256(String s) {
        return encrypt(s, "SHA-256");
    }

    public static String encryptMD5(String s) {
        return encrypt(s, "MD5");
    }

    public static String encrypt(String s, String messageDigest) {
        try {
            MessageDigest md = MessageDigest.getInstance(messageDigest);
            byte[] passBytes = s.getBytes();
            md.reset();
            byte[] digested = md.digest(passBytes);
            StringBuffer sb = new StringBuffer();
            for(int i=0;i<digested.length;i++)
                sb.append(Integer.toHexString(0xff & digested[i]));
            return sb.toString();
        }
        catch (Exception e) {
            return s;
        }

    }
    

	// 평문, key
    public static String encrypt_AES(String strPlain) {
    	String rtnStr = "";
    	
    	System.out.println("## encrypt_AES" );
    	
        try {
        	
     	   
        	   // 암호화에 사용할 키, 디폴트로 128bit(16Byte)
            //String encryptionKey = "happyprogrammer!";
//        	String encryptionAESKey   = "kakaoDevTest2020";
            
            // 암호화할 문자열
            String target = strPlain; 
            
         
            // AES로 암호화 =================================================
            
             // AES Cipher 객체 생성
            Cipher cipher = Cipher.getInstance("AES");
            
            // 암호화 Chipher 초기화 
            SecretKeySpec secretKeySpec = new SecretKeySpec(encryptionAESKey.getBytes(),"AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
            
            // 암호화 완료 
            byte[] encryptBytes = cipher.doFinal(target.getBytes("UTF-8"));
            rtnStr = encryptBytes.toString();
            
            System.out.println("## AES ENC 1 [" + encryptBytes +"]"); // => 똑같은 암호화키로 복호화
            System.out.println("## AES ENC 2 " + rtnStr			); // => 똑같은 암호화키로 복호화
            System.out.println("## AES ENC 3 " + new String(encryptBytes)); // => 똑같은 암호화키로 복호화
            
            
            // AES로 복호화 =================================================
            
//            // 복호화 Chipher 초기화, 똑같은 암호화키로 복호화
//            cipher.init(cipher.DECRYPT_MODE, secretKeySpec);
//            byte[] decryptBytes = cipher.doFinal(encryptBytes);
//            System.out.println("## AES DEC " +  new String(decryptBytes, "UTF-8"));

   

    	   
    	   return rtnStr;
        }
        catch (Exception e) {
        	System.out.println("## encrypt_AES Exception " + e.getMessage());
            return rtnStr;
        }

    }
    
    
	// 평문, key
    public static String dencrypt_AES(String strPlain) {
    	String rtnStr = "";
    	
    	System.out.println("## dencrypt_AES "  + strPlain );
    	
        try {
          
             // AES Cipher 객체 생성
            Cipher cipher = Cipher.getInstance("AES");
            
            // 복호화 Chipher 초기화 
            SecretKeySpec secretKeySpec = new SecretKeySpec(encryptionAESKey.getBytes(),"AES");
//            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
            
            
            // AES로 복호화 =================================================
            
//            byte[] encryptBytes = strPlain.getBytes();
            byte[] encryptBytes = strPlain.getBytes( "UTF-8");
            System.out.println("## encryptBytes "  + encryptBytes );
            
            // 복호화 Chipher 초기화, 똑같은 암호화키로 복호화
            cipher.init(cipher.DECRYPT_MODE, secretKeySpec);
            byte[] decryptBytes = cipher.doFinal(encryptBytes);
            
            rtnStr = decryptBytes.toString();
            System.out.println("## AES DEC " +  new String(decryptBytes, "UTF-8"));
            System.out.println("## AES DEC " +  rtnStr );

    	   
    	   return rtnStr;
        }
        catch (Exception e) {
        	System.out.println("## dencrypt_AES Exception " + e.getMessage());
            return rtnStr;
        }

    }    

//
//	   SecretKey clsKey = new SecretKeySpec( strPassWord.getBytes(), "AES" );
//	   IvParameterSpec clsIV = new IvParameterSpec( strIv.getBytes() );
//	 
//	   Cipher clsCipher = Cipher.getInstance( "AES/CBC/PKCS5Padding" );
//
//
//
//	   // 암호화 한다.
//	   clsCipher.init( Cipher.ENCRYPT_MODE, clsKey, clsIV );
//	   byte [] arrEnc = clsCipher.doFinal( strPlain.getBytes("utf-8") );
//	   
//
//	   // 복호화 한다.
//	   clsCipher.init( Cipher.DECRYPT_MODE, clsKey, clsIV );
//	   byte [] arrDec = clsCipher.doFinal( arrEnc );
//	   
//
//	   // 복호화가 정상적으로 되었는지 화면에 출력하여서 확인한다.​
//	   System.out.println( "[" + new String( arrDec, "utf8" ) + "]" );
//	  }

	

    
    
    public static String encrypt_RSA(String strPlain) {
    	String rtnStr = "";
    	
        try {
    
        		// RSA 공개키/개인키를 생성한다.
            // 암호화할 문자열
            String target = strPlain; 
            
         
            // RSA 로 암호화 =================================================
            
            // RSA 비밀키와 공개키를 생성
            KeyPairGenerator keypairgen = KeyPairGenerator.getInstance("RSA");
            KeyPair keyPair = keypairgen.generateKeyPair();
            RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
            RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
            
             // Cipher 객체 생성과 비밀키 초기화
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, privateKey);
            
            // 암호화 완료 
            byte[] encryptBytes = cipher.doFinal(target.getBytes());
            System.out.println(new String(encryptBytes)); // => 암호화되어 읽지못함

  
		     
            // RSA로 복호화 =================================================
            
            // 복호화 Chipher 초기화, 비밀키와 쌍인 공개키로 복호화함.
            cipher.init(cipher.DECRYPT_MODE, publicKey);
            byte[] decryptBytes = cipher.doFinal(encryptBytes);
            System.out.println(new String(decryptBytes));

  
        }        
	    catch (Exception e) {
	        return rtnStr;
	    }
	        
        return rtnStr;
    }


    
}
