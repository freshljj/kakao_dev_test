package kakao_test;

public class validationCheck {

	// ����üũ�� validation �Լ�
	// chkMinLen �̻�
	// chkMaxLen ���� 
	public static boolean validationChkLen( int chkMinLen , int chkMaxLen , String sChkValue){
		
		boolean bValidate = true;
		System.out.println(" ##  " + chkMinLen +  " / " + chkMaxLen+ " / "+ sChkValue.length() );
		
		if(sChkValue.isEmpty()				) {			bValidate = false;		}
		
		if( chkMinLen == chkMaxLen ) {
				if(sChkValue.length() != chkMaxLen	) {			bValidate = false;		}
		}else {			
				if(sChkValue.length() < chkMinLen	) {			bValidate = false;		}		
				if(sChkValue.length() > chkMaxLen	) {			bValidate = false;		}
		}	
			
		System.out.println(" ##  bValidate " + bValidate);
		return bValidate;

	}
	
	public static boolean validationChkMinLen( int chkMinLen , String sChkValue){
		
		return validationChkLen(chkMinLen , 99999 , sChkValue);
	}

	public static boolean validationChkmaxLen( int chkMaxLen , String sChkValue){
		
		return validationChkLen( 1 , chkMaxLen , sChkValue);
	}

	public static boolean validationChkLen( int chkLen , String sChkValue){
		
		return validationChkLen( chkLen , chkLen , sChkValue);
	}

	
}
